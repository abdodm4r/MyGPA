# MyGPA — Android APK project

This project packages the GPA calculator as a standalone Android WebView app. The launcher name and icon use the new **MyGPA** branding. Local browser storage is enabled to retain saved GPA data on-device.

## Build an APK automatically (recommended)
1. Create a GitHub repository and upload the contents of this folder.
2. Go to **Actions** and enable workflows if prompted.
3. Select **Build MyGPA APK** and press **Run workflow**.
4. After the run completes, download the `MyGPA-debug-apk` artifact. It contains the installable debug APK.

Alternatively, build locally with Android SDK and Gradle 8.7+: run `gradle assembleDebug` from this folder. The APK is generated under `app/build/outputs/apk/debug/`.
